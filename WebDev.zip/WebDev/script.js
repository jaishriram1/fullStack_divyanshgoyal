var studentId=3465;
let studentName="Sachin";
const studentFee=400000;

console.log(studentId);
console.log(studentName);

function sum() {
    let sum=55;
    if(sum==55){
        var fullname="abcde";
    }
    console.log(fullname);
    
}
sum();
console.log(fullname);

// const salary=45678;   // cannot re-declare const type variable
// let salary=47856;

